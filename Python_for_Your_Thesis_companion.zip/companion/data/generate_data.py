"""Generate the simulated teaching data for 'Python for Your Thesis'.

All values are invented for teaching. The raw files deliberately contain the
faults that Chapter 14 cleans: a lowercase and a trailing-space treatment name,
one shoot mass typed in mg, one tipped-over pot with missing values, one soil P
value below the detection limit, a German CSV export and a lab Excel report.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent   # the data folder
RAW, CLEAN, EXTRA = ROOT / "raw", ROOT / "clean", ROOT / "extra"
for d in (RAW, CLEAN, EXTRA):
    d.mkdir(parents=True, exist_ok=True)

NAN = np.nan
treat = (["Control"] * 5 + ["Mineral"] * 5 + ["Compost"] * 5 + ["Digestate"] * 5)
pot_id = [f"P{i:02d}" for i in range(1, 21)]
replicate = [1, 2, 3, 4, 5] * 4
shoot = [9.8, 11.2, 10.5, 12.1, 10.9,
         16.2, 17.5, 15.9, 18.1, 16.8,
         14.6, 13.9, 15.8, 14.2, 16.1,
         15.1, 16.4, NAN, 15.9, 13.6]
root = [3.9, 4.3, 4.1, 4.6, 4.2,
        4.8, 5.1, 4.6, 5.3, 4.9,
        5.4, 5.0, 5.8, 5.2, 5.9,
        4.9, 5.3, NAN, 5.1, 4.5]
plant_p = [1.62, 1.55, 1.71, 1.48, 1.66,
           2.84, 2.91, 2.76, 2.98, 2.88,
           2.31, 2.24, 2.42, 2.19, 2.37,
           2.52, 2.61, NAN, 2.58, 2.43]
soil_p = [9.5, 11.2, NAN, 8.7, 10.4,
          52.3, 55.1, 49.8, 57.6, 53.4,
          38.4, 36.9, 42.7, 35.2, 41.5,
          44.8, 47.3, 45.9, 48.6, 43.1]
soil_ph = [6.3, 6.4, 6.2, 6.3, 6.4,
           6.2, 6.1, 6.2, 6.1, 6.2,
           6.6, 6.7, 6.6, 6.5, 6.7,
           6.5, 6.4, 6.5, 6.6, 6.4]
acp = [182, 175, 191, 169, 186,
       138, 145, 132, 141, 136,
       231, 224, 245, 219, 238,
       204, 212, 198, 215, 207]

clean = pd.DataFrame({
    "pot_id": pot_id, "treatment": treat, "replicate": replicate,
    "shoot_dm": shoot, "root_dm": root, "plant_p": plant_p,
    "soil_p": soil_p, "soil_ph": soil_ph, "acp": acp})
clean.to_csv(CLEAN / "trial.csv", index=False)

# ---------- raw 1: pot list (English CSV) ----------
treat_raw = list(treat)
treat_raw[6] = "mineral"        # P07
treat_raw[13] = "compost "      # P14, trailing space
notes = [""] * 20
notes[17] = "pot tipped over in week 4"  # P18
notes[2] = "soil P below detection limit"  # P03
pd.DataFrame({"pot_id": pot_id, "treatment": treat_raw,
              "replicate": replicate, "notes": notes}).to_csv(
    RAW / "pots.csv", index=False)

# ---------- raw 2: balance export (German Excel CSV) ----------
shoot_raw = list(shoot)
shoot_raw[11] = 13900.0          # P12 typed in mg
def de(x):
    if x != x:  # NaN
        return ""
    s = f"{x:.1f}" if x < 1000 else f"{x:.0f}"
    return s.replace(".", ",")
lines = ["pot_id;shoot_dm_g;root_dm_g"]
for p, s, r in zip(pot_id, shoot_raw, root):
    lines.append(f"{p};{de(s)};{de(r)}")
(RAW / "balance.csv").write_text("\n".join(lines) + "\n", encoding="utf-8")

# ---------- raw 3: lab report (Excel, title rows, two sheets) ----------
soil_raw = [("<LOD" if v != v else v) for v in soil_p]
soil_tab = pd.DataFrame({"sample": pot_id, "soil_p_mg_kg": soil_raw,
                         "ph_cacl2": soil_ph, "acp_nmol_g_h": acp})
plant_tab = pd.DataFrame({"sample": pot_id, "plant_p_mg_g": plant_p})
with pd.ExcelWriter(RAW / "lab_report.xlsx", engine="openpyxl") as xw:
    soil_tab.to_excel(xw, sheet_name="soil", index=False, startrow=3)
    plant_tab.to_excel(xw, sheet_name="plant", index=False, startrow=3)
    for name in ("soil", "plant"):
        ws = xw.sheets[name]
        ws["A1"] = "Soil and plant laboratory - analysis report"
        ws["A2"] = "Project: maize pot trial 2026, detection limit soil P: 5 mg/kg"

# ---------- raw 4: photometer export with standards ----------
rng = np.random.default_rng(2026)
std_conc = [0, 0.5, 1, 2, 3, 4]
slope, icpt = 0.205, 0.012
std_abs = [icpt + slope * c + rng.normal(0, 0.004) for c in std_conc]
sample_conc = [(v / 20 if v == v else 0.09) for v in soil_p]
sample_abs = [icpt + slope * c + rng.normal(0, 0.003) for c in sample_conc]
rows = ["# Photometer export, molybdenum blue method, 880 nm",
        "# Extraction: 5 g soil in 100 mL CAL solution",
        "sample_id,type,conc_mg_l,absorbance"]
for i, (c, a) in enumerate(zip(std_conc, std_abs)):
    rows.append(f"S{i},standard,{c},{a:.4f}")
for p, a in zip(pot_id, sample_abs):
    rows.append(f"{p},sample,,{a:.4f}")
(RAW / "photometer.csv").write_text("\n".join(rows) + "\n", encoding="utf-8")

# ---------- extra: plant height over six weeks ----------
final = {"Control": 92, "Mineral": 131, "Compost": 118, "Digestate": 124}
recs = []
for p, t in zip(pot_id, treat):
    k = final[t] * rng.normal(1, 0.04)
    for week in range(1, 7):
        h = k / (1 + np.exp(-0.95 * (week - 3.2)))
        recs.append({"pot_id": p, "treatment": t, "week": week,
                     "height_cm": round(h + rng.normal(0, 1.2), 1)})
pd.DataFrame(recs).to_csv(EXTRA / "plant_height.csv", index=False)

# ---------- extra: weather station, June ----------
days = pd.date_range("2026-06-01", periods=30, freq="D")
tmax = np.round(21 + 4 * np.sin(np.arange(30) / 4.5) + rng.normal(0, 1.8, 30), 1)
tmin = np.round(tmax - 9 + rng.normal(0, 1.5, 30), 1)
rain = np.where(rng.random(30) < 0.33, np.round(rng.gamma(1.6, 3.5, 30), 1), 0.0)
pd.DataFrame({"date": days.strftime("%Y-%m-%d"), "tmin": tmin, "tmax": tmax,
              "rain_mm": rain}).to_csv(EXTRA / "weather_june.csv", index=False)

# ---------- extra: skylark transects ----------
pd.DataFrame({"transect": [f"T{i}" for i in range(1, 11)],
              "habitat": ["arable"] * 5 + ["grassland"] * 5,
              "skylarks": [4, 7, 5, 6, 3, 9, 11, 8, 12, 10]}).to_csv(
    EXTRA / "skylarks.csv", index=False)

# ---------- extra: plate reader kinetics ----------
t = np.arange(0, 65, 5)
plate = {"time_min": t}
for name, rate in (("A", 41.0), ("B", 58.5), ("C", 27.2)):
    plate[f"well_{name}"] = np.round(120 + rate * t + rng.normal(0, 18, t.size), 0)
pd.DataFrame(plate).to_csv(EXTRA / "plate_reader.csv", index=False)

print("data written to", ROOT)
